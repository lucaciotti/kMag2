<?php
include_once "autoload.php";

$title = "Disponibilità Articolo";
$page_content = "content/disponibilita_art.php";
$page_footer = "content/footer_pistole_askarticolo.php";
include "masterpistole.php";
?>