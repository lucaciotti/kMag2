<?php
include_once "autoload.php";

$title = "Inventario";
$page_content = "content/inventario.php";
$page_footer = "content/footer_pistole_inventario.php";
include "masterpistole.php";

?>
