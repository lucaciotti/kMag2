<?php
//quà ci vanno le dichiarazioni delle variabili di ambiente