<?php
include_once "autoload.php";

$title = "Riepilogo Inventario";
$page_content = "content/invTable.php";
$page_footer = "footer.php";
include "master-pc.php";

?>
