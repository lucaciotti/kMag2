<div class="row">
    <div class="col col-12 ">
        <img src="images/logo.jpg" height="20px" class="pr-2">
        <label class="text-xs font-italic">Krona Koblenz S.p.A.</label>
    </div>
</div>
