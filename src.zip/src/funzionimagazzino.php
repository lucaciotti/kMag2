<?php
include_once "autoload.php";

$title = "Funzioni Magazzino";
$page_content = "content/funzionimagazzino.php";
$page_footer = "footer_pistole.php";
include "masterpistole.php";

?>
