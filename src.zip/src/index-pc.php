<?php
include_once "autoload.php";

$title = "Home Page";
$page_content = "content/index-pc.php";
include "masterpistole.php";

?>