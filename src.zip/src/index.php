<?php
include_once "autoload.php";

$title = "Home Page";
$page_content = "content/index.php";
include "masterpistole.php";

?>