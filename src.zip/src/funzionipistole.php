<?php
include_once "autoload.php";

$title = "Funzioni Pistole";
$page_content = "content/funzionipistole.php";
$page_footer = "footer_pistole.php";
include "masterpistole.php";

?>
