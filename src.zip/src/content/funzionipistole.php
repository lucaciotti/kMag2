<div class="row pt-2 pb-2">
    <div class="col col-6">
        <a href="funzionimagazzino.php" class="btn btn-dark btn-block"><i class="fa fa-warehouse fa-3x pt-2"></i><p>Funzioni Magazzino</p></a>
    </div>
    <div class="col col-6">
        <button class="btn btn-dark btn-block"><i class="fa fa-truck-moving fa-3x pt-2"></i><p>Ricevimento Merci</p></button>
    </div>
</div>
<div class="row pt-2 pb-2">
    <div class="col col-6">
        <button class="btn btn-dark btn-block"><i class="fa fa-industry fa-3x pt-2"></i><p>Produzione Interna</p></button>
    </div>
    <div class="col col-6">
        <button class="btn btn-dark btn-block"><i class="fa fa-truck-loading fa-3x pt-2"></i><p>Spedizione Merci</p></button>
    </div>
</div>
<div class="row pt-2 pb-2">
    <div class="col col-6">
        <a href="inventario.php" class="btn btn-dark btn-block"><i class="fa fa-book-open fa-3x pt-2"></i><p>Inventario</p></a>
    </div>
</div>
