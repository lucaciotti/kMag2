<div class="row pt-2 pb-2">
    <div class="col col-12">
        <a href="askarticolo.php" class="btn btn-dark btn-block"><i class="fa fa-warehouse fa-3x pt-2"></i><p>Ricerca Disponibilità Articoli</p></a>
    </div>
</div>
<div class="row pt-2 pb-2">
    <div class="col col-12">
        <a href="changeubiart.php" class="btn btn-dark btn-block"><i class="fa fa-truck-moving fa-3x pt-2"></i><p>Sostituzioni Ubicazione</p></a>
    </div>
</div>