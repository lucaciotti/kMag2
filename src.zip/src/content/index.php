<div class="row">
    <div class="col col-12 text-center pt-5">
        <a href="funzionipistole.php">
            <h1 class="text-gray">K-MAG</h1>
            <img src="images/logo.jpg">
            <h4 class="text-gray">Clicca per iniziare</h4>
        </a>
    </div>
</div>