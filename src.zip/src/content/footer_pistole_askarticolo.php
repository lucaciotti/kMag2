<div class="row">
    <div class="col col-2 ">
        <img src="images/logo.jpg" height="20px">
    </div>
    <div class="col col-8">
        <label class="text-xs font-italic">Krona Koblenz S.p.A.</label>
    </div>
    <div class="col col-1 text-right">
        <a href="askarticolo.php"><i class="fas fa-search"></i></a>
    </div>
    <div class="col col-1 text-right">
        <a href="funzionipistole.php"><i class="fas fa-home"></i></a>
    </div>
</div>
