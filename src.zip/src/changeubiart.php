<?php
include_once "autoload.php";

$title = "Sostituzione Ubicazione";
$page_content = "content/changeubiart.php";
$page_footer = "content/footer_pistole_changeubiart.php";
include "masterpistole.php";
?>
