<?php
include_once "autoload.php";

$title = "Funzioni PC";
$page_content = "content/funzioni-pc.php";
$page_footer = "footer.php";
include "master-pc.php";

?>
